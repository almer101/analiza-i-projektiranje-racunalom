Pozicionirati se u folder s izvornim datotekama i popratnim datotekama.
Program se zatim pokrece naredbom:
"python3 main.py" ili "python main.py" ovisno o tome kako se na doticnom racunalu pokrece python verzije 3 koja na racunalu treba biti unaprijed instalirana.